<?php

namespace App\Filament\Resources\FlowTemplateResource\Pages;

use App\Filament\Resources\FlowTemplateResource;
use Filament\Resources\Pages\CreateRecord;

class CreateFlowTemplate extends CreateRecord
{
    protected static string $resource = FlowTemplateResource::class;
}
